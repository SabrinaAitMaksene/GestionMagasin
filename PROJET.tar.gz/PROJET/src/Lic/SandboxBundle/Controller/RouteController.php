<?php

namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class RouteController extends Controller
{
    public function testsAction($year,$month,$filename,$ext)
    {
        $args = array(
            'year' => $year,
            'month' => $month,
            'filename' => $filename,
            'ext' => $ext
        );

        return $this->render('@LicSandbox/Route/index.html.twig', $args  );
    }

    public function testfinalAction($year)
    {
        $args = array(
            'year' => $year
        );

        return $this->render('@LicSandbox/Route/index2.html.twig', $args);
    }
}