<?php

namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class MenuController extends Controller
{

    public function menuAction()
    {
        $tab = array (
            'mentions' => array(
                'Info' => array(
                    'nom' => 'Informatique',
                    'parcours' => array(
                        'Informatique',
                        'Image',
                    ),
                    'responsable' => 'SJ',
                ),
                'PC' => array(
                    'nom' => 'Physique-Chimie',
                    'parcours' => array(
                        'Physique',
                        'Chimie minérale',
                    ),
                    'responsable' => 'GA',
                ),
                'Bio' => array(
                    'nom' => 'Biologie',
                    'parcours' => array(
                        'Géologie',
                        'Biologie végétale',
                        'Biologie animale',
                    ),
                    'responsable' => 'MN',
                ),
            ),
            'ues' => array(
                array(
                    'nom' => 'Algo 1',
                    'volume' => 54,
                ),
                array(
                    'nom' => 'Maths discrètes',
                    'volume' => 40,
                ),
                array(
                    'nom' => 'Anglais S1',
                    'volume' => 20,
                ),
                array(
                    'nom' => 'Anglais S2',
                    'volume' => 20,
                ),
                array(
                    'nom' => 'Projet',
                    'volume' => 70,
                ),
            ),
        );

        $args = array(
            'arg1' => 'Marine',
            'arg2' => 'marine.droit@etu.univ-poitiers.fr',
            'arg3' => $tab
        );
        return $this->render('@LicSandbox/Twig/menu.html.twig',$args);
    }

}