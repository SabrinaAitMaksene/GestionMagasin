<?php


namespace Lic\SandboxBundle\Controller;


use Lic\SandboxBundle\Entity\Film;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DoctrineController extends Controller
{

    public function listAction() { /* skip */}
    public function viewAction($id) { /* skip */}

    public function addendurAction()
    {
        $em = $this->getDoctrine()->getEntityManager();

        $film = new Film();
        $film->setNom('Le Grand Bleu');
        $film->setAnnee(1988);
        $film->setEnstock(true);
        $film->setPrix(9.99);
        $film->setQuantite(88);

        $em->persist($film);
        $em->flush();

        return $this->redirectToRoute('lic_sandbox_doctrine_view', array('id' => $film->getId()));
    }

    public function modifieendurAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $filmRepository = $em->getRepository('LicSandboxBundle:Film');

        $film = $filmRepository->find(21);
        $film->setNom('Le Grand Rouge');

        $em->flush();

        return $this->redirectToRoute('lic_sandbox_doctrine_view', array('id' => $film->getId()));
    }

    public function effaceendurAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $filmRepository = $em->getRepository('LicSandboxBundle:Film');

        $film = $filmRepository->find(21);
        $em->remove($film);

        $em->flush();

        //return $this->redirectToRoute('lic_sandbox_doctrine_view', array('id' => $film->getId()));
    }

    public function listFilmAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $filmRepository = $em->getRepository('LicSandboxBundle:Film');

        $films = $filmRepository->findAll();

        $args = array('films' => $films);


        return $this->render('@LicSandbox/Entite/testFilm.html.twig',$args);

    }
}