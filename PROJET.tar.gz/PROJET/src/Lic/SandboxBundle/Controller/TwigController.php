<?php

namespace Lic\SandboxBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class TwigController extends Controller
{
    public function test1Action()
    {
        return $this->render('@LicSandbox/Twig/vue1.html.twig');
    }

    public function test2Action()
    {
        return $this->render('@LicSandbox/Twig/vue2.html.twig');
    }

    public function test3Action()
    {
        return $this->render('@LicSandbox/Twig/vue3.html.twig');
    }

    public function test4Action()
    {
        return $this->render('@LicSandbox/Twig/vue4.html.twig');
    }

    public function test5Action()
    {
        return $this->render('@LicSandbox/Twig/vue5.html.twig');
    }

    public function test6Action()
    {
        return $this->render('@LicSandbox/Twig/vue6.html.twig');
    }
}