<?php

namespace Lic\SandboxBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Critiques
 *
 * @ORM\Table(name="sb_critiques")
 * @ORM\Entity(repositoryClass="Lic\SandboxBundle\Repository\CritiquesRepository")
 */
class Critiques
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="id_film", type="integer")
     */
    private $idFilm;

    /**
     * @var int
     *
     * @ORM\Column(name="note", type="integer", nullable=true, options={"comment" = "entre 0 et 5"})
     */
    private $note;

    /**
     * @var string
     *
     * @ORM\Column(name="avis", type="text")
     */
    private $avis;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idFilm
     *
     * @param integer $idFilm
     *
     * @return Critiques
     */
    public function setIdFilm($idFilm)
    {
        $this->idFilm = $idFilm;

        return $this;
    }

    /**
     * Get idFilm
     *
     * @return int
     */
    public function getIdFilm()
    {
        return $this->idFilm;
    }

    /**
     * Set note
     *
     * @param integer $note
     *
     * @return Critiques
     */
    public function setNote($note)
    {
        $this->note = $note;

        return $this;
    }

    /**
     * Get note
     *
     * @return int
     */
    public function getNote()
    {
        return $this->note;
    }

    /**
     * Set avis
     *
     * @param string $avis
     *
     * @return Critiques
     */
    public function setAvis($avis)
    {
        $this->avis = $avis;

        return $this;
    }

    /**
     * Get avis
     *
     * @return string
     */
    public function getAvis()
    {
        return $this->avis;
    }
}

