<?php

namespace Lic\SandboxBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LicSandboxBundle extends Bundle
{
}
