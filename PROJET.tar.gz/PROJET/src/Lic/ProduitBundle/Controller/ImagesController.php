<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ImagesController extends Controller
{
    public function listAction($page){
        $args = array(
            'page' => $page,
        );
        return $this->render('@LicProduit/Images/listImages.html.twig',$args);
    }

    public function viewAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Images/viewImages.html.twig',$args);
    }

    public function createAction(){
        return $this->render('@LicProduit/Images/createImages.html.twig');
    }

    public function updateAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Images/updateImages.html.twig',$args);
    }

    public function deleteAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Images/deleteImages.html.twig',$args);
    }
}