<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Lic\ProduitBundle\Entity\Magasins;

class MagasinsController extends Controller
{
    public function listAction($sort){

        $em = $this->getDoctrine()->getEntityManager();
        $magasinsRepository = $em->getRepository('LicProduitBundle:Magasins');
        $mpr = $em->getRepository('LicProduitBundle:Prod_mag');
        $magasins = $magasinsRepository->findAll();

        $stock = array();

        if ($sort == 0){
            usort($magasins, function ($a, $b)
            {
                if (strtolower($a->getNom()) == strtolower($b->getNom())){
                    return 0;
                }
                else if (strtolower($a->getNom()) > strtolower($b->getNom())) {
                    return 1;
                }
                else {
                    return -1;
                }
            }
            );
        }
        else {

            $magStock = array();

            foreach ($magasins as $m){
                array_push($magStock, array("mag" => $m, "stock"=>$mpr->StockMag($m->getId())) );
            }

            usort($magStock, function($a, $b)
                {
                    if (($a['stock']) == ($b['stock'])){
                        return 0;
                    }
                    else if (($a['stock']) > ($b['stock'])){
                        return -1;
                    }
                    else{
                        return 1;
                    }
                }
            );

            unset($magasins);
            $magasins = array();

            foreach($magStock as $cle => $m){
                array_push($magasins,$m['mag']);
                array_push($stock,$m['stock']);
            }

        }


        $args = array(
            'sort' => $sort,
            'magasins' => $magasins,
            'stock' => $stock
        );
        return $this->render('@LicProduit/Magasins/listMagasins.html.twig',$args);
    }

    public function viewAction($cle){

        $em = $this->getDoctrine()->getEntityManager();
        $mag = $em->getRepository('LicProduitBundle:Magasins')->find($cle);
        $liste = $em->getRepository('LicProduitBundle:Prod_mag')->findByMagasin($mag);
        $prods = $em->getRepository('LicProduitBundle:Produits');

        $args = array(
            'magasins' => $liste,
            'id' => $mag->getNom()
        );

        return $this->render('@LicProduit/Magasins/viewMagasins.html.twig',$args);
    }

    public function createAction(Request $request){

        if($request->isMethod('POST')){

            $em = $this->getDoctrine()->getEntityManager();
            $nomMag = $request->request->get('nomMag');

            $verif = $em->getRepository('LicProduitBundle:Magasins')->findByNom($nomMag);

            if ($verif == null){
                $mag = new Magasins();
                $mag->setNom($nomMag);

                $em->persist($mag);
                $em->flush();

                $this->addFlash(
                    'message', "Le magasasin $nomMag a bien été ajouté à la base de donnée !"
                );

                return $this->redirectToRoute('lic_produit_magasins_list');
            }
            else {

                $this->addFlash(
                    'message', "Le magasasin $nomMag existe déjà dans la base de donnée il n'as pas été ajouté."
                );

                return $this->redirectToRoute('lic_produit_magasins_create');
            }
        }

        return $this->render('@LicProduit/Magasins/createMagasins.html.twig');
    }

    public function updateAction($cle, Request $request){

        $em = $this->getDoctrine()->getEntityManager();
        $magasinsRepository = $em->getRepository('LicProduitBundle:Magasins');
        $magasins = $magasinsRepository->find($cle);

        $nomAnMag = $magasins->getNom();

        if($request->isMethod('POST')){

            $nomMag = $request->request->get('nomMag');
            $magasins->setNom($nomMag);

            $em->flush();

            $this->addFlash(
                'message', "Le magasasin $nomAnMag a bien été modifié dans la base de donnée !"
            );

            return $this->redirectToRoute('lic_produit_magasins_list');
        }

        $args = array(
            'cle' => $cle,
            'Nom' => $nomAnMag);

        return $this->render('@LicProduit/Magasins/updateMagasins.html.twig', $args);
    }

    public function deleteAction($cle){

        $em = $this->getDoctrine()->getEntityManager();
        $magasinsRepository = $em->getRepository('LicProduitBundle:Magasins');
        $magasins = $magasinsRepository->find($cle);

        $prod = $em->getRepository('LicProduitBundle:Prod_mag')->findByMagasin($magasins);

        echo count($prod);

        $nomMag = $magasins->getNom();

        if (count($prod) == 0){

            $em->remove($magasins);
            $em->flush();


            $this->addFlash(
                'message', "Le magasasin $nomMag a bien été supprimé de la base de donnée !");
        }
        else{
            $this->addFlash(
                'message', "Il reste des produits dans le magasin, $nomMag n'a pas été supprimé !");
        }

        return $this->redirectToRoute('lic_produit_magasins_list');
    }

}