<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class AccueilController extends Controller
{
    public function indexAction()
    {
        return $this->render('LicProduitBundle:Accueil:index.html.twig');
    }

}
