<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class MenuController extends Controller
{
    public function menuAction()
    {

        $em = $this->getDoctrine()->getEntityManager();

        $mag = $em->getRepository('LicProduitBundle:Magasins')->findAll();
        $prod = $em->getRepository('LicProduitBundle:Produits')->findAll();

        $args = array(
            "nbmag" => count($mag),
            "nbprod" => count($prod)
        );

        return $this->render('@LicProduit/Layout/Menu.html.twig',$args);
    }


}