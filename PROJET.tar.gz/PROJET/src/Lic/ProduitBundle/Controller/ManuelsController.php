<?php

namespace Lic\ProduitBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ManuelsController extends Controller
{
    public function listAction($page){
        $args = array(
            'page' => $page,
        );
        return $this->render('@LicProduit/Manuels/listManuel.html.twig',$args);
    }

    public function viewAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Manuels/viewManuel.html.twig',$args);
    }

    public function createAction(){
        return $this->render('@LicProduit/Manuels/createManuel.html.twig');
    }

    public function updateAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Manuels/updateManuel.html.twig',$args);
    }

    public function deleteAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Manuels/deleteManuel.html.twig',$args);
    }
}