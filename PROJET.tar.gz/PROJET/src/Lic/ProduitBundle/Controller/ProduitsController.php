<?php

namespace Lic\ProduitBundle\Controller;

use Lic\ProduitBundle\Entity\Manuels;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Lic\ProduitBundle\Entity\Produits;
use Lic\ProduitBundle\Entity\Prod_mag;
use Symfony\Component\Validator\Constraints\DateTime;

class ProduitsController extends Controller
{
    public function listAction($page){

        $em = $this->getDoctrine()->getEntityManager();
        $produitsRepository = $em->getRepository('LicProduitBundle:Produits');
        $produits = $produitsRepository->findAll();

        $args = array(
            'page' => $page,
            'produits' => $produits
        );

        return $this->render('@LicProduit/Produits/listProduits.html.twig',$args);
    }

    public function viewAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Produits/viewProduits.html.twig',$args);
    }

    public function createAction(Request $request){

        if($request->isMethod('POST')){

            $em = $this->getDoctrine()->getEntityManager();



            $nomProd = $request->request->get('nomProd');
            $verif = $em->getRepository('LicProduitBundle:Produits')->findByDenomination($nomProd);

            if( $verif == null ){
                $codeProd = $request->request->get('codeProd');
                $dateProd = $request->request->get('dateProd');
                $actifProd = $request->request->get('actifProd');
                $descriptionProd = $request->request->get('descriptionProd');

                $URLMan = $request->request->get('URLMan');
                $SommaireMan = $request->request->get('SommaireMan');


                $man = new Manuels();
                $man->setUrl($URLMan);
                $man->setSommaire($SommaireMan);

                $prod = new Produits();
                $prod->setDenomination($nomProd);
                $prod->setCode($codeProd);
                $prod->setDateCreation(new \DateTime($dateProd));
                $prod->setActif($actifProd);
                $prod->setDescriptif($descriptionProd);
                $prod->setManuel($man);


                $em->persist($man);
                $em->persist($prod);
                $em->flush();

                $magasinsRepository = $em->getRepository('LicProduitBundle:Magasins');

                $mag1 = $magasinsRepository->find($request->request->get('Mag1'));
                $prix1 = $request->request->get('PrixUnitaire1');
                $Quantite1 = $request->request->get('Quantite1');

                $mag2 = $magasinsRepository->find($request->request->get('Mag2'));
                $prix2 = $request->request->get('PrixUnitaire2');
                $Quantite2 = $request->request->get('Quantite2');

                $mag3 = $magasinsRepository->find($request->request->get('Mag3'));
                $prix3 = $request->request->get('PrixUnitaire3');
                $Quantite3 = $request->request->get('Quantite3');

                if($prix1 != null){
                    $prod_mag = new Prod_mag();
                    $prod_mag->setMagasin($mag1);
                    $prod_mag->setProduit($prod);
                    $prod_mag->setPrixUnitaire($prix1);
                    $prod_mag->setQuantite($Quantite1);

                    $em->persist($prod_mag);
                    $em->flush();

                }

                if($prix2 != null){
                    $prod_mag = new Prod_mag();
                    $prod_mag->setMagasin($mag2);
                    $prod_mag->setProduit($prod);
                    $prod_mag->setPrixUnitaire($prix2);
                    $prod_mag->setQuantite($Quantite2);

                    $em->persist($prod_mag);
                    $em->flush();

                }

                if($prix3 != null){
                    $prod_mag = new Prod_mag();
                    $prod_mag->setMagasin($mag3);
                    $prod_mag->setProduit($prod);
                    $prod_mag->setPrixUnitaire($prix3);
                    $prod_mag->setQuantite($Quantite3);

                    $em->persist($prod_mag);
                    $em->flush();

                }

                $this->addFlash(
                    'message', "Le produit $nomProd a bien été ajouté à la base de donnée !"
                );



                return $this->redirectToRoute('lic_produit_produits_list');
            }
            else{

                $this->addFlash(
                    'message', "Le produit $nomProd existe déjà dans la base de données, il n'as pas été ajouté."
                );

                return $this->redirectToRoute('lic_produit_produits_create');
            }


        }

        $em = $this->getDoctrine()->getEntityManager();

        $magasinsRepository = $em->getRepository('LicProduitBundle:Magasins');
        $magasins = $magasinsRepository->findAll();

        $args = array(
            'magasins' => $magasins,
        );

        return $this->render('@LicProduit/Produits/createProduits.html.twig',$args);
    }

    public function updateAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Produits/updateProduits.html.twig',$args);
    }

    public function deleteAction($cle){
        $args = array(
            'cle' => $cle
        );
        return $this->render('@LicProduit/Produits/deleteProduits.html.twig',$args);
    }
}