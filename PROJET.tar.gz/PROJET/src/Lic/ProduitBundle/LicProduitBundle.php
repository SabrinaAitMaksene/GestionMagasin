<?php

namespace Lic\ProduitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LicProduitBundle extends Bundle
{
}
