<?php

namespace Lic\ProduitBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Prod_mag
 *
 * @ORM\Table(name="prod_produits_magasins")
 * @ORM\Entity(repositoryClass="Lic\ProduitBundle\Repository\Prod_magRepository")
 */
class Prod_mag
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Lic\ProduitBundle\Entity\Magasins")
     * @ORM\JoinColumn(name = "id_magasin", nullable=false)
     */

    private $magasin;

    /**
     * @ORM\ManyToOne(targetEntity="Lic\ProduitBundle\Entity\Produits")
     * @ORM\JoinColumn (name = "id_produit", nullable=false)
     */

    private $produit;

    /**
     * @var int
     *
     * @ORM\Column(name="quantite", type="integer")
     */
    private $quantite;

    /**
     * @var float
     *
     * @ORM\Column(name="prix_unitaire", type="float")
     */
    private $prixUnitaire;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Produit
     *
     * @param integer $Produit
     *
     * @return Prod_mag
     */
    public function setProduit($Produit)
    {
        $this->produit = $Produit;

        return $this;
    }

    /**
     * Get Produit
     *
     * @return int
     */
    public function getProduit()
    {
        return $this->produit;
    }

    /**
     * Set Magasin
     *
     * @param integer $Magasin
     *
     * @return Prod_mag
     */
    public function setMagasin($Magasin)
    {
        $this->magasin = $Magasin;

        return $this;
    }

    /**
     * Get Magasin
     *
     * @return int
     */
    public function getMagasin()
    {
        return $this->magasin;
    }

    /**
     * Set quantit�e
     *
     * @param integer $quantit�e
     *
     * @return Prod_mag
     */
    public function setQuantite($quantite)
    {
        $this->quantite = $quantite;

        return $this;
    }

    /**
     * Get quantit�e
     *
     * @return int
     */
    public function getQuantite()
    {
        return $this->quantite;
    }

    /**
     * Set prixUnitaire
     *
     * @param float $prixUnitaire
     *
     * @return Prod_mag
     */
    public function setPrixUnitaire($prixUnitaire)
    {
        $this->prixUnitaire = $prixUnitaire;

        return $this;
    }

    /**
     * Get prixUnitaire
     *
     * @return float
     */
    public function getPrixUnitaire()
    {
        return $this->prixUnitaire;
    }
}

